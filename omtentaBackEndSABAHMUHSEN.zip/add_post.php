<?php include_once('config.php');?>
<html>
<head>
<title>insert data in database using PDO(php data object)</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
      
<form action="" method="post"> 
<label>Title :</label>
<input type="text" name="title" id="name" required="required" placeholder="Please Enter title"/><br /><br />
<label>description :</label>
<input type="text" name="description" id="email" required="required" placeholder="Please Enter description"/><br/><br />
<label>content :</label>
<input type="text" name="content" id="city" required="required" placeholder="Please Enter Content"/><br/><br />
<label>author :</label>
<input type="text" name="author" id="city" required="required" placeholder="Please Enter Yr Name"/><br/><br />


<input type="submit" value=" Submit " name="submit"/><br />
</form>
<a href="index.php">return</a>

<?php
if(isset($_POST["submit"])){

try {
$sql = "INSERT INTO post (title, description, content, author)
VALUES ('".$_POST["title"]."','".$_POST["description"]."','".$_POST["content"]."','".$_POST["author"]."')";
if ($pdo->query($sql)) {
echo "<script type= 'text/javascript'>alert('New Record Inserted Successfully');</script>";
}
else{
echo "<script type= 'text/javascript'>alert('Data not successfully Inserted.');</script>";
}

}
catch(PDOException $e)
{
echo $e->getMessage();
}

}
?>
</body>
</html>

