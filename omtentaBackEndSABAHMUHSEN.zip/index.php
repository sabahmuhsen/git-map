
<?php 
include_once("config.php");?>
<a href="add_post.php">Add new post</a>

<?php
$result = $pdo->query("call sp_test");
while($row = $result->fetch()) {
    ?>
    <section>
        <h2><?php echo $row['title']; ?></h2>
        <p><?php echo $row['description']; ?></p>
        <p><?php echo $row['content']; ?></p>
        <span><?php echo $row['DateTime']; ?></span><br>
        <?php echo " <a href=\"delete.php?id=$row[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a><br>";        
         echo "<a href=\"edit.php?id=$row[id]\">Edit</a>" ?>
        
    </section>         
    <?php
}


