<?php
$databaseHost = 'localhost';    // localhost
$databaseName = 'blog';         // database
$databaseUsername = 'root';     // username
$databasePassword = 'root';     // password


try {
//Creating connection for mysql
$pdo = new PDO("mysql:host=$databaseHost;dbname=blog", $databaseUsername, $databasePassword);
// set the PDO error mode to exception
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
echo "Connection failed: " . $e->getMessage();
}
?>

