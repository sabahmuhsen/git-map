<!DOCTYPE html> 
<html> 
<head> 
<meta charset="UTF-8"> 
<title></title> 
</head> 
<body> 
<a href="index.php">Home</a> 
<br/><br/> 

<form action="" method="post">
<label>Title :</label>
<input type="text" name="title" required="required" placeholder="Please Enter Name"/><br /><br />
<label>description :</label>
<input type="text" name="description" required="required" placeholder="john123@gmail.com"/><br/><br />
<label>content :</label>
<input type="text" name="content" required="required" placeholder="Please Enter Your City"/><br/><br />
<label>author :</label>
<input type="text" name="author" required="required" placeholder="Please Enter Your City"/><br/><br />


<input type="submit" value=" Submit " name="submit"/><br />
</form>

    </body>
</html>


<?php 
include_once("config.php");
$id = $_GET['id'];

if(isset($_POST["submit"])){

$sql = " UPDATE post SET title = :title,description = :description,content = :content,author = :author WHERE id = :id";
$stmt = $pdo->prepare($sql);                                  
$stmt->bindParam(':title', $_POST['title']);       
$stmt->bindParam(':description', $_POST['description']);    
$stmt->bindParam(':content', $_POST['content']);
$stmt->bindParam(':author', $_POST['author']); 
$stmt->bindParam(':id', $id);   
$stmt->execute(); 
}
?>
